function [ELEMENTS,NODES,MODEL] = set_model(INPUT)

% INPUT data are transferred into the structures ELEMENTS, NODES, MODEL

%% ELEMENTS
ELEMENTS = struct();

nELEMENTS = size((INPUT.elements),1); % number of the elements of the structure 

for i=1:nELEMENTS % to save the data of every element 
    ELEMENTS(i).nodes = INPUT.elements(i,1:2);
    ELEMENTS(i).EA = INPUT.section_prop(1);
    ELEMENTS(i).EJ = INPUT.section_prop(2);

    if INPUT.section_prop(2) == 0
        ELEMENTS(i).type = 'truss';
        ELEMENTS(i).dofs = 4;
    else
        ELEMENTS(i).type = 'beam';
        ELEMENTS(i).dofs = 6;
    end
    
    for j=1:size((INPUT.spc),1)
        if INPUT.spc(j,1)==i
            ELEMENTS(i).dofs = ELEMENTS(i).dofs - 1;
        end
    end
end

%% NODES
% NODES = 
%     1�4 struct array with fields:
%         coord_x % coord_x: node x coordinate
%         coord_y % coord_y: node y coordinate
%         ndof % ndof: number of nodal dofs (2 for 'truss', 6 for 'beams')

NODES = struct();

nNODES = size((INPUT.nodes),1); % number of the nodes of the structure 

for i=1:nNODES % to save the data of every node 
    NODES(i).coord_x = INPUT.nodes(i,2);
    NODES(i).coord_y = INPUT.nodes(i,3);
    
    NODES(i).ndof = ELEMENTS(1).dofs/2;    
end

%% MODELS
% MODEL = 
%     struct with fields:
%         ndof: 8 % ndof: tot number of dofs for the unconstr system
%         nels: 4 % nels: total number of elements
%         nnodes: 4 % nnodes: total number of nodes
%         K: [3�3 double] % K: stiffness matrix of constr structure
%         F: [3�1 double] % F: load vector of constr structure
%         constr_dofs: [1 2 7 8 5] % constr_dofs: position of constrained dofs
%         free_dofs: [3 4 6] % free_dofs: position of free dofs
%         nfree_dofs: 3 % nfree_dofs: number of dofs
%         K_unc: [8�8 double] % K_unc: stiffness matrix of unconstr structure
%         F_unc: [8�1 double] % F_unc: load vector of unconstr struct
%         U: [3�1 double] % U: displacement vector (only free dofs)
%         U_unc: [8�1 double] % U_unc: displacement vector (all dofs)

MODEL = struct();

if INPUT.section_prop(2) == 0 % truss
    n = 2;
    MODEL.ndof = size(INPUT.nodes,1)*2;
else
    n = 3;
    MODEL.ndof = size(INPUT.nodes,1)*3;
end
MODEL.nels = size(INPUT.elements,1);
MODEL.nnodes = nNODES;
MODEL.K = zeros(MODEL.ndof);
MODEL.F = zeros(MODEL.ndof,1);

for i=1:size(INPUT.load,1)
    if INPUT.load(i,2)==1
    	MODEL.F(n*INPUT.load(i,1)-(n-1),1) = INPUT.load(i,3);
    elseif INPUT.load(i,2)==2
        MODEL.F(n*INPUT.load(i,1)-(n-2),1) = INPUT.load(i,3);
    elseif INPUT.load(i,2)==3
        MODEL.F(n*INPUT.load(i,1),1) = INPUT.load(i,3);
    end
end

for i=1:length(INPUT.spc)
    if INPUT.spc(i,2)==1 % constraint over x
        MODEL.constr_dofs(i) = n*INPUT.spc(i,1)-(n-1);
    elseif INPUT.spc(i,2)==2 % constraint over y
        MODEL.constr_dofs(i) = n*INPUT.spc(i,1)-(n-2);
    elseif INPUT.spc(i,2)==3 % constraint over th
        MODEL.constr_dofs(i) = n*INPUT.spc(i,1)-(n-3);
    end
end

if length(INPUT.spc)==0
    MODEL.constr_dofs = [];
end

p = 1;
for i=1:MODEL.ndof
    const = 0;
    for j=1:length(MODEL.constr_dofs)
        if MODEL.constr_dofs(j)==i
            const = 1;
        end
    end
    if (const==0)
        MODEL.free_dofs(p) = i;
        p = p+1;
    end
end

MODEL.nfree_dofs = size(MODEL.free_dofs,2);

% Variable that saves the number of the exercise 
MODEL.ex = INPUT.ex;

end