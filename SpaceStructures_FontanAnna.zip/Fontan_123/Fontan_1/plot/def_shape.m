function [] = def_shape(INPUT,MODEL,ELEMENTS)
figure
hold on
grid on

nNODES = size(INPUT.nodes,1);
nEL = size(INPUT.elements,1);

if strcmp(ELEMENTS(1).type,'truss')
    n=2;
else % beam
    n=3;
end
    
for i=1:nEL
    n_f(ELEMENTS(i).nodes(1)) = ELEMENTS(i).nodal_forces;
    n_f(ELEMENTS(i).nodes(2)) = ELEMENTS(i).nodal_forces;
end

for i=1:nNODES
    x_unc(i) = INPUT.nodes(i,2)+MODEL.U_unc(n*i-(n-1));
    y_unc(i) = INPUT.nodes(i,3)+MODEL.U_unc(n*i-(n-2));
end

for i=1:nNODES
    scatter(INPUT.nodes(i,2),INPUT.nodes(i,3),20,'black','filled')
    scatter(x_unc(i),y_unc(i),20,'c','filled')
end

for i=1:nEL
    el = [INPUT.elements(i,1),INPUT.elements(i,2)];
    
    % Constrainted structure
    Dx = [INPUT.nodes(el(1),2),INPUT.nodes(el(2),2)];
    Dy = [INPUT.nodes(el(1),3),INPUT.nodes(el(2),3)];
    in_s = plot(Dx,Dy,'black--');
    
    Dx_unc = [x_unc(el(1)),x_unc(el(2))];
    Dy_unc = [y_unc(el(1)),y_unc(el(2))];
    def_s = plot(Dx_unc,Dy_unc,'c');
end

title('Deformed shape')
legend([in_s def_s],{'Initial structure','Deformed structure'})
xlabel('x [mm]')
ylabel('y [mm]')

end