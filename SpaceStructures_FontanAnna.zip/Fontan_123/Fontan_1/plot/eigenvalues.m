function [] = eigenvalues(INPUT,MODEL,type,mode,k)

hold on
grid on

nNODES = size(INPUT.nodes,1);
nEL = size(INPUT.elements,1);

if strcmp(type,'truss')
    n=2;
else % beam
    n=3;
end
def = zeros(1,nNODES*n);
for i=1:nNODES
    def(n*i-(n-1)) = INPUT.nodes(i,2);
    def(n*i-(n-2)) = INPUT.nodes(i,3);
end

def = (def + mode)';

x_def = def(1:n:MODEL.ndof);
y_def = def(2:n:MODEL.ndof);

for i=1:nNODES
    scatter(INPUT.nodes(i,2),INPUT.nodes(i,3),20,'black','filled')
    scatter(x_def(i,1),y_def(i,1),20,'c','filled')
end

for i=1:nEL
    el = [INPUT.elements(i,1),INPUT.elements(i,2)];
    
    % Constrainted structure
    Dx = [INPUT.nodes(el(1),2),INPUT.nodes(el(2),2)];
    Dy = [INPUT.nodes(el(1),3),INPUT.nodes(el(2),3)];
    plot(Dx,Dy,'black--')
    
    Dx_def = [x_def(el(1)),x_def(el(2))];
    Dy_def = [y_def(el(1)),y_def(el(2))];
    plot(Dx_def,Dy_def,'c')
end

title(['Mode ',num2str(k)])
xlabel('x [mm]')
ylabel('y [mm]')

end