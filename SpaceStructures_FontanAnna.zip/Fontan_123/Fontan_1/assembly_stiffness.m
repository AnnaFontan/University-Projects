function MODEL = assembly_stiffness(ELEMENTS,MODEL)

% The assembly of the stiffness matrix is readily performed by using the vectors of
% pointers to directly set the contribution of each element in the correct position of
% the global stiffness matrix

% --- Assembly stiffness matrix

for i = 1 : MODEL.nels
    ptrs = ELEMENTS( i ).ptrs;
    K_el = ELEMENTS( i ).K_el;
    MODEL.K( ptrs, ptrs ) = MODEL.K( ptrs, ptrs ) + K_el;
end

end