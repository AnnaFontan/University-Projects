function MODEL = solve_structure(MODEL)

constr_dofs = MODEL.constr_dofs;

% Store unconstrained K and F
MODEL.K_unc = MODEL.K;
MODEL.F_unc = MODEL.F;

% Impose constraints
MODEL.K(constr_dofs,:) = []; % Remove rows of constrained dofs
MODEL.K(:,constr_dofs) = []; % Remove cols of constrained dofs
MODEL.F(constr_dofs) = []; % Remove rows of constrained dofs
 
% Solve problem
MODEL.U = MODEL.K \ MODEL.F;
 
% Expand displacements to the global vector
MODEL.U_unc = zeros(MODEL.ndof,1);
MODEL.U_unc(MODEL.free_dofs) = MODEL.U;

end