clear all
close all
clc

addpath 'input'
addpath 'plot'

%% 1. Pre-process
% Preparation of the data
INPUT = input_model_1a();

%% 2. Solution
% Analysis of the structure
[ELEMENTS,NODES,MODEL] = analyze_structure(INPUT);

%% 3. Post-processingy
% Recovery of those quantities to be used during the analysis of results
ELEMENTS = force_recovery(MODEL,ELEMENTS);

%% 4. Plot 
def_shape(INPUT,MODEL,ELEMENTS); 

%% 5. Free vibrations
figure(2) % Solution of the eigenvalue problem
sgtitle('Free vibrations')

INPUT.mass = INPUT.mass(:,3);
M = diag(INPUT.mass(MODEL.free_dofs));
[MODEL.v,MODEL.Ome2] = eig(MODEL.K,M);
sqrt(diag(MODEL.Ome2))

for i=1:4 % for i=1:size(MODEL.v,2)
    mode = zeros(1,MODEL.ndof);
    nexttile
    mode(MODEL.free_dofs) = MODEL.v(:,i);
    eigenvalues(INPUT,MODEL,ELEMENTS(1).type,mode,i);
end

%% 6. Results
MODEL.U
