function [ELEMENTS] = set_pointers(ELEMENTS,NODES,nels)

% The function writes the pointers associated with the generic i-th element in the
% field ELEMENT(i).ptrs

for i=1:nels % to save the data of every element 
    if strcmp(ELEMENTS(i).type,'truss') % truss
        n = 2;
    else % beam
        n = 3;    
    end
    
    if n==2 % truss
        el1 = n*ELEMENTS(i).nodes(1)-1;
        el2 = n*ELEMENTS(i).nodes(1);
        el3 = n*ELEMENTS(i).nodes(2)-1;
        el4 = n*ELEMENTS(i).nodes(2);
        ELEMENTS(i).ptrs = sort([el1,el2,el3,el4]);    
    else
        el1 = n*ELEMENTS(i).nodes(1)-2;
        el2 = n*ELEMENTS(i).nodes(1)-1;
        el3 = n*ELEMENTS(i).nodes(1);
        el4 = n*ELEMENTS(i).nodes(2)-2;
        el5 = n*ELEMENTS(i).nodes(2)-1;
        el6 = n*ELEMENTS(i).nodes(2);
        ELEMENTS(i).ptrs = sort([el1,el2,el3,el4,el5,el6]);   
    end
end

end