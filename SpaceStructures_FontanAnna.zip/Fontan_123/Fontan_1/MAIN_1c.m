clear all
close all
clc

addpath 'input'
addpath 'plot'

%% 1. Pre-process
% Preparation of the data
[INPUT,FORCES] = input_model_1c();

%% 2. Solution
% Analysis of the structure
[ELEMENTS,NODES,MODEL] = analyze_structure(INPUT);

%% 3. Post-processingy
% Recovery of those quantities to be used during the analysis of results
[ELEMENTS,FORCES] = force_recovery(MODEL,ELEMENTS,FORCES);

%% 4. Plot 
def_shape(INPUT,MODEL,ELEMENTS); 

%% 5. Results
MODEL.U

%% 6. Evaluate the reaction forces (nodes 5, 6)
[Fx_react,Fy_react,M_react] = reaction_forces(FORCES,MODEL.constr_dofs)