clear all
close all
clc

addpath 'input'
addpath 'plot'

%% 1. Pre-process
% Preparation of the data
[INPUT,FORCES] = input_model_1d();

%% 2. Solution
% Analysis of the structure
[ELEMENTS,NODES,MODEL] = analyze_structure(INPUT);

%% 3. Post-processingy
% Recovery of those quantities to be used during the analysis of results
[ELEMENTS,FORCES] = force_recovery(MODEL,ELEMENTS,FORCES);

%% 4. Evaluation of the reaction forces (nodes 5, 6)
[Fx_react,Fy_react,M_react] = reaction_forces(FORCES,MODEL.constr_dofs)

%% 5. Lagrange multipliers
% U_aug(1:MODEL.ndof) == MODEL.U_unc
[U_aug] = lagrangian_multipliers(MODEL);
lambda = U_aug(MODEL.ndof+1:end) % Lagrangian multipliers

%% 6. Plot 
% Deformed shape: solution of the linear static problem
def_shape(INPUT,MODEL,ELEMENTS); 

