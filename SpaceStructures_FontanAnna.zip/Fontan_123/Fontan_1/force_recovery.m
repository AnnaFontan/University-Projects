function [ELEMENTS,FORCES] = force_recovery(MODEL,ELEMENTS,FORCES)

% --- Force recovery

for i = 1 : MODEL.nels
    T = ELEMENTS(i).T;
    ptrs = ELEMENTS(i).ptrs;
    U_el_loc = T * MODEL.U_unc( ptrs ); % Displacements of the element in local coordinates
    nodal_forces = ELEMENTS(i).K_el_loc * U_el_loc;
    
    %(take force in node 2: >0 in traction)
    ELEMENTS(i).nodal_forces = nodal_forces(2);
    
    % angles with respect to the first and the second nodes of the element
    alpha(1) = ELEMENTS(i).alpha*pi/180;
    alpha(2) = alpha(1) + pi;
    
    if (strcmp(MODEL.ex,'1c'))||(strcmp(MODEL.ex,'1d'))
        nodes = ELEMENTS(i).nodes;
        for j = 1:length(nodes)
            R = [cos(alpha(j)) -sin(alpha(j)) 0; sin(alpha(j)) cos(alpha(j)) 0; 0 0 -1];
            forces = R*nodal_forces(3*j-2:3*j); % rotated forces in the global reference system
            FORCES(nodes(j)).Fx = FORCES(nodes(j)).Fx + forces(1); 
            FORCES(nodes(j)).Fy = FORCES(nodes(j)).Fy + forces(2);
            FORCES(nodes(j)).M = FORCES(nodes(j)).M + forces(3);
        end
    end
    
    
end

end