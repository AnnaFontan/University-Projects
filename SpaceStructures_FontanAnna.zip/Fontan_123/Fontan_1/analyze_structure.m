function [ELEMENTS, NODES, MODEL] = analyze_structure(INPUT)

% The function analyze_structure represents the core of the program, and is
% divided into a number of functions

% --- Set model
[ELEMENTS,NODES,MODEL] = set_model(INPUT);

% MODEL
% --- Set pointers
ELEMENTS = set_pointers(ELEMENTS,NODES,MODEL.nels);

% --- Build element stiffness matrices
ELEMENTS = element_stiffness(ELEMENTS,NODES,MODEL.nels);

% --- Assembly stiffness matrix
MODEL = assembly_stiffness(ELEMENTS,MODEL);

% --- Impose constraints and solve
MODEL = solve_structure(MODEL);

end