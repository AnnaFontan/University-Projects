function [Fx_react,Fy_react,M_react] = reaction_forces(FORCES,constr_dofs)
% Evaluation of the reaction forces in correspondence of the nodes contrained

idx_x = 1;
idx_y = 1;
idx_M = 1;

for i = 1:length(constr_dofs)    
    c = constr_dofs(i); % selected contraint
    
     % To identify the node related to the constraint:
    n = floor(c/3)+1;
    
    switch (mod(c,3))
        case 1 % constraint over x
            Fx_react(idx_x) = FORCES(n).Fx;
            idx_x = idx_x+1;
        case 2 % constraint over y
            Fy_react(idx_y) = FORCES(n).Fy;
            idx_y = idx_y+1;
        case 0 % constraint over th
            M_react(idx_M) = FORCES(n-1).M;
            idx_M = idx_M+1;
        otherwise
    end
end

end