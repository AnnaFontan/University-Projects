function [U_aug] = lagrangian_multipliers(MODEL)
% Evaluation of the Lagrangian multipliers

U = MODEL.U_unc; 
nCONS = size(MODEL.constr_dofs,2); % number of constraints
nDOF = MODEL.ndof; % number of DoFs

% Build matrix of the coefficients A
A = zeros(nCONS,nDOF);
for i = 1:nCONS
    A(i,MODEL.constr_dofs(i)) = 1;
end
b = zeros(nCONS,1); % vector collecting the constraints
K_aug = MODEL.K_unc;

for i = 1:nDOF
    for j = 1:nCONS
        K_aug(nDOF+j,i) = A(j,i);
        K_aug(i,nDOF+j) = A(j,i); 
    end
end

f_aug = [MODEL.F_unc; b];
U_aug = K_aug\f_aug;

end