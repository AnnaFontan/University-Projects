
function INPUT = input_model_1b()

% The input file is written from the user by specifying the characteristics of the
% model to be analyzed. The data are organized into the structure INPUT, which is
% divided into different fields

% -- Init
INPUT = struct();

% -- Elements

INPUT.elements = [1 2 1;
                  1 3 1;
                  2 4 1;
                  2 3 1;
                  1 4 1;
                  3 4 1;
                  3 5 1;
                  3 6 1;
                  4 5 1;
                  4 6 1];

% -- Nodes
l = 360; % [mm]
INPUT.nodes = [ 1 2*l l;
                2 2*l 0
                3 l l;
                4 l 0;
                5 0 l;
                6 0 0];

% -- Section properties
E = 10^4; % [Mpa]
INPUT.A = 10; % [mm^2]

INPUT.section_prop = [E*INPUT.A 0]; % [EA EJ]

% -- Concentrated mass
M = 1e-4; % [t]
INPUT.mass = [1 1 M;
              1 2 M;
              2 1 M;
              2 2 M;
              3 1 M;
              3 2 M;
              4 1 M;
              4 2 M;
              5 1 M;
              5 2 M;
              6 1 M;
              6 2 M]; % [ ID_node component magn]    
          
% -- Loading conditions
P = 100; % [N]
INPUT.load = [1 2 -P;
              5 2 P;
              5 1 -2*P;
              6 1 2*P];

% -- Boundary conditions
INPUT.spc = [];

% -- Exercise
INPUT.ex = '1b';

end