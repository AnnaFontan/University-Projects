function [INPUT,FORCES] = input_model_1c()

% The input file is written from the user by specifying the characteristics of the
% model to be analyzed. The data are organized into the structure INPUT, which is
% divided into different fields


% -- Init
INPUT = struct();
FORCES = struct();

% Data
M = 1e-4; % [t]
l = 360; % [mm]
INPUT.E = 10^4; % [Mpa]
A = 10; % [mm^2]
J = 1/3*M*l^2;
P = 100; % [N]

% -- Elements
INPUT.elements = [1 2 1;
                  1 3 1;
                  2 4 1;
                  2 3 1;
                  1 4 1;
                  3 4 1;
                  3 5 1;
                  3 6 1;
                  4 5 1;
                  4 6 1];

% -- Nodes
INPUT.nodes = [ 1 2*l l;
                2 2*l 0
                3 l l;
                4 l 0;
                5 0 l;
                6 0 0];

% -- Section properties
INPUT.section_prop = [INPUT.E*A INPUT.E*J]; % [EA EJ]

% -- Concentrated mass
INPUT.mass = [1 1 M;
              1 2 M;
              1 3 M;
              2 1 M;
              2 2 M;
              2 3 M;
              3 1 M;
              3 2 M;
              3 3 M;
              4 1 M;
              4 2 M;
              4 3 M;
              5 1 M;
              5 2 M;
              5 3 M;
              6 1 M;
              6 2 M
              6 3 M;]; % [ ID_node component magn]    
          
% -- Loading conditions
INPUT.load = [2 2 -P;
              4 2 -P];

% -- Boundary conditions
INPUT.spc = [5 1;
             5 2;
             5 3;
             6 1;
             6 2;
             6 3];

for i = 1:size(INPUT.nodes,1)
    FORCES(i).Fx = 0;
    FORCES(i).Fy = 0;
    FORCES(i).M = 0;
end
         
% -- Exercise
INPUT.ex = '1c';

end