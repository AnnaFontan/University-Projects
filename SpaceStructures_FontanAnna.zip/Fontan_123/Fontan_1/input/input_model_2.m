function INPUT = input_model_2()

% The input file is written from the user by specifying the characteristics of the
% model to be analyzed. The data are organized into the structure INPUT, which is
% divided into different fields

% --- Input
% INPUT.elements : [ node_A node_B ID_prop ]
% INPUT.nodes : [ ID_node x_coord y_coord ]
% INPUT.E : Young's modulus
% INPUT.section_prop : [ A J ] -- set J = 0 for truss
% INPUT.mass : [ ID_node component magn]
% INPUT.load : [ ID_node component magn ]
% INPUT.solution : 'static' or 'eigenmodes'
% INPUT.spc : [ ID_node component ]

% -- Init
INPUT = struct();

% Input data
l = 2540; % [mm]
h1 = 3810; % [mm]
h2 = 5080; % [mm]
P = 35; % [N]
INPUT.E = 200*10^3; % [MPa]
A = 10; % [mm^2]
M = 1e-4; % [t]

% -- Elements
INPUT.elements = [1 3 1;
                  1 4 1;
                  3 4 1;
                  3 5 1;
                  4 6 1;
                  5 6 1;
                  5 7 1;
                  6 8 1;
                  7 8 1;
                  7 2 1;
                  2 8 1;
                  4 5 1;
                  3 6 1;
                  6 7 1;
                  5 8 1];

% -- Nodes
INPUT.nodes = [ 1 0 0;
                2 4*l 0
                3 l 0;
                4 l h1;
                5 2*l 0;
                6 2*l h2;
                7 3*l 0;
                8 3*l h1];

% -- Section properties
INPUT.section_prop = [INPUT.E*A 0]; % [EA EJ]

% -- Concentrated mass
INPUT.mass = [1 1 M;
              1 2 M;
              2 1 M;
              2 2 M;
              3 1 M;
              3 2 M;
              4 1 M;
              4 2 M;
              5 1 M;
              5 2 M;
              6 1 M;
              6 2 M;
              7 1 M;
              7 2 M;
              8 1 M;
              8 2 M;]; % [ ID_node component magn]    
          
% -- Loading conditions
INPUT.load = [4 2 -P;
              6 2 -P;
              8 2 -P];

% -- Boundary conditions
INPUT.spc = [1 1
             1 2
             2 1
             2 2];

% -- Exercise
INPUT.ex = '2';

end