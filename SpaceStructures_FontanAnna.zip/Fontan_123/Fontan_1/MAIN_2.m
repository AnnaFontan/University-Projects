clear all
close all
clc

addpath 'input'
addpath 'plot'

%% 1. Pre-process
% Preparation of the data
INPUT = input_model_2();

%% 2. Solution
% Analysis of the structure
[ELEMENTS,NODES,MODEL] = analyze_structure(INPUT);

%% 3. Post-processingy
% Recovery of those quantities to be used during the analysis of results
ELEMENTS = force_recovery(MODEL,ELEMENTS);

%% 4. Plot 
def_shape(INPUT,MODEL,ELEMENTS); 

% --- Solution of the eigenvalue problem
figure
INPUT.mass = INPUT.mass(:,3);
M = diag(INPUT.mass(MODEL.free_dofs));
[MODEL.v,MODEL.Ome2] = eig(MODEL.K,M);
om = sqrt(diag(MODEL.Ome2));
sgtitle('Free vibrations')

% for i=1:size(MODEL.v,2)
for i=1:4
    mode = zeros(1,MODEL.ndof);
    subplot(2,2,i)
    mode(MODEL.free_dofs) = MODEL.v(:,i);
    eigenvalues(INPUT,MODEL,ELEMENTS(1).type,mode,i);
end

%% 5. Results
MODEL.U
om(1:4)