clear all
close all
clc

addpath 'input'
addpath 'plot'

%% 1. Pre-process
% Preparation of the data
INPUT = input_model_1b();

%% 2. Solution
% Analysis of the structure
[ELEMENTS,NODES,MODEL] = analyze_structure(INPUT);

%% 3. Post-processingy
% Recovery of those quantities to be used during the analysis of results
ELEMENTS = force_recovery(MODEL,ELEMENTS);

%% 4. Eigenvalue problem 
INPUT.mass = INPUT.mass(:,3);
M = diag(INPUT.mass(MODEL.free_dofs));
[MODEL.v,MODEL.Ome2] = eig(MODEL.K,M);

%% 5. Plot 
def_shape(INPUT,MODEL,ELEMENTS); 

%% 6. Results
% Determinant of the stiffness matrix
detK = det(MODEL.K);

% Eigenvalues for the free vibration problem
eigenvalues = real(sqrt(diag(MODEL.Ome2)));

% Internal state of stress
for i = 1:MODEL.nels
    sigma(i) = ELEMENTS(i).nodal_forces/INPUT.A;
end
sigma;

