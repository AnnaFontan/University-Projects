function [B,J] = get_B_matrix(xi,eta,xy_nodes)
% Build matrix B and the Jacobian of the isoparametric transformation

% Derivatives in the computational domain
if (size(xy_nodes,1)==4) % number of columns
    N_xi(1) = (-1 + eta)/4;
    N_xi(2) = (1 - eta)/4;
    N_xi(3) = (1 + eta)/4;
    N_xi(4) = (-1 - eta)/4;

    N_eta(1) = (-1 + xi)/4;
    N_eta(2) = (-1 - xi)/4;
    N_eta(3) = (1 + xi)/4;
    N_eta(4) = (1 - xi)/4;
        
elseif (size(xy_nodes,1)==8)
    N_xi(1) = (1 - eta)*(2*xi + eta)/4;
    N_xi(2) = (1 - eta)*(2*xi - eta)/4;
    N_xi(3) = (1 + eta)*(2*xi + eta)/4;
    N_xi(4) = (1 + eta)*(2*xi - eta)/4;
    N_xi(5) = -xi*(1 - eta);
    N_xi(6) = (1 - eta^2)/2;
    N_xi(7) = -xi*(1 + eta);
    N_xi(8) = -(1 - eta^2)/2;
    
    N_eta(1) = (1 - xi)*(2*eta + xi)/4;
    N_eta(2) = (1 + xi)*(2*eta - xi)/4;
    N_eta(3) = (1 + xi)*(2*eta + xi)/4;
    N_eta(4) = (1 - xi)*(2*eta - xi)/4;
    N_eta(5) = -(1 - xi^2)/2;
    N_eta(6) = - eta*(1 + xi);
    N_eta(7) = (1 - xi^2)/2;
    N_eta(8) = -eta*(1 - xi);
end

for i=1:size(N_xi,2)
    EtaXi(:,i) = [N_xi(i);N_eta(i)];
end

% Build the Jacobian of the isoparametric transformation
J = EtaXi*xy_nodes;
XY = J\EtaXi;

% Build matrix B
B = zeros(3,size(XY,2)*2);
B(1,1:size(XY,2)) = XY(1,1:size(XY,2)); % 1st row of B
B(2,size(XY,2)+1:2*size(XY,2)) = XY(2,1:size(XY,2)); % 2nd row of B
B(3,1:size(XY,2)) = XY(2,1:size(XY,2)); % 3rd row of B
B(3,size(XY,2)+1:2*size(XY,2)) = XY(1,1:size(XY,2)); % 3rd row of B


end