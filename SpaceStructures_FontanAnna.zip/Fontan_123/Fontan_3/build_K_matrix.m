function [MODEL,RESULT] = build_K_matrix(MODEL,PROPERTY,RESULT)

A = PROPERTY.A;

% --- Integration rule parameters
xGauss = MODEL.int_rule.x;
wGauss = MODEL.int_rule.w;
nint_p = length(xGauss);

for i = 1:MODEL.nels % Loop over the elements
   
    % --- Initialize
    K_el = zeros(2*MODEL.eltype,2*MODEL.eltype);
    
    % --- Matrix of nodal coordinates
    el_nodes = MODEL.elements(i,:);
    xy_nodes = [MODEL.nodes(el_nodes,1) MODEL.nodes(el_nodes,2)];

    % --- Integrate stiffness matrix
    for iG = 1:nint_p % Loop over x- and y-direction for numerical integration
        for jG = 1:nint_p
            xi = xGauss(jG);
            eta = xGauss(iG);
            [B,J] = get_B_matrix(xi,eta,xy_nodes);
            detJ = det(J);
            
            if (iG==1)&&(jG==1)
                switch (i) % i corresponds to the element
                    case 1
                        RESULT.J1_44_bilinear = J;
                    case 27
                        RESULT.J27_44_bilinear = J;
                    case 33
                        RESULT.J33_44_bilinear = J; 
                    otherwise
                end
            end
            
            
            % --- Stiffness matrix
            K_el = K_el + wGauss(iG)*wGauss(jG)*(B'*A*B*detJ);
        end
    end    
    
    % --- Assemble contribution
    ptrs = MODEL.ptrs(i,:);
    MODEL.K(ptrs,ptrs) = MODEL.K(ptrs,ptrs) + K_el;

end
    
end