function [MODEL,PROPERTY,POST] = set_model(INPUT)
% To define the structures used

%% MODEL
MODEL = struct();

MODEL.elements = INPUT.elements;
MODEL.nodes = INPUT.nodes;

switch (INPUT.integration_pts) % number of points of integration
    case 1 
        MODEL.int_rule.x = 0;
        MODEL.int_rule.w = 2;
    case 2
        MODEL.int_rule.x = [-1/sqrt(3) 1/sqrt(3)];
        MODEL.int_rule.w = [1 1];
    case 3 
        MODEL.int_rule.x = [-sqrt(.6) 0 sqrt(.6)];
        MODEL.int_rule.w = [5/9 8/9 5/9];
    otherwise
end

nNODES = size(MODEL.nodes,1);
for i=1:nNODES 
    MODEL.pos(i,1) = i; % first column: u_x
    MODEL.pos(i,2) = i+nNODES; % second column: u_y
end

MODEL.dofs = max(max(MODEL.pos)); % number of DOFs

% Number of elements and nodes of the structure
MODEL.nels = size(INPUT.elements,1);
MODEL.nnodes = nNODES;
MODEL.eltype = size(INPUT.elements,2);

MODEL.K = zeros(MODEL.nnodes*2);
MODEL.F = zeros(MODEL.nnodes*2,1);

for j=1:size(INPUT.load,1)
    if INPUT.load(j,2)==1 % loads along x direction
        MODEL.F(INPUT.load(j,1),1) = INPUT.load(j,3);
    else % loads along y direction
        MODEL.F(INPUT.load(j,1)+nNODES,1) = INPUT.load(j,3);
    end
end

for i=1:size(INPUT.spc,1)
    if INPUT.spc(i,2) == 1 % contraint over x
        MODEL.constr_dofs(i,1) = INPUT.spc(i,1);
    else % contraint over y
        MODEL.constr_dofs(i,1) = INPUT.spc(i,1) + nNODES;
    end        
end

if length(INPUT.spc)==0
    MODEL.constr_dofs = [];
end

for i=1:MODEL.dofs
    MODEL.free_dofs(1,i) = i;
end
MODEL.free_dofs(MODEL.constr_dofs') = []; 
MODEL.nfree_dofs = size(MODEL.free_dofs,2);


%% PROPERTY
PROPERTY = struct();
PROPERTY.t = INPUT.t; % thickness
PROPERTY.A = INPUT.E*INPUT.t/(1-INPUT.nu^2)*[1 INPUT.nu 0; INPUT.nu 1 0; 0 0 (1-INPUT.nu)/2];


%% POST
POST = struct();


end
