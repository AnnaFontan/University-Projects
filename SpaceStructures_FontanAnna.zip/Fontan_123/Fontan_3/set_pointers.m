function MODEL = set_pointers(MODEL)

nEL = MODEL.nels; % number of elements
nodes_el = size(MODEL.elements,2); % number of nodes per element

for i=1:nEL % i-element selected
    for k=1:nodes_el
        ux = MODEL.pos(MODEL.elements(i,k),1);
        uy = MODEL.pos(MODEL.elements(i,k),2);
                        
        MODEL.ptrs(i,k) = ux;
        MODEL.ptrs(i,k+nodes_el) = uy;
    end
end

end