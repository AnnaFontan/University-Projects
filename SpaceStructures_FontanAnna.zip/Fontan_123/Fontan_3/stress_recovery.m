function POST = stress_recovery(MODEL,PROPERTY,POST)

C = PROPERTY.A/PROPERTY.t;

% --- Integration rule parameters
xGauss = MODEL.int_rule.x;
nint_p = length(xGauss);
 
% Initialize
a_xx = [];
a_yy = [];
a_xy = [];

n = size(MODEL.elements,2); % number of nodes per element

for i = 1:MODEL.nels % loop over the elements

    % Initialize
    sxx_ip = [];
    syy_ip = [];
    sxy_ip = [];

    % Nodal coordinates
    el_nodes = MODEL.elements(i,:);    
    xy_nodes = [MODEL.nodes(el_nodes,1) MODEL.nodes(el_nodes,2)];

    % Unconstrained displacements
    u_x = MODEL.U_unc(el_nodes,1);
    u_y = MODEL.U_unc(el_nodes + MODEL.nnodes,1);
    
    idx = 0;

    % --- Integrate stiffness matrix
    for iG = 1:nint_p % Loop over x- and y-direction for numerical integration
        for jG = 1:nint_p
            idx = idx + 1;
            xi = xGauss(jG);
            eta = xGauss(iG);
            
            [B,detJ] = get_B_matrix(xi,eta,xy_nodes);
                
            ip = C*B*[u_x;u_y];
    
            POST.sxx_ip(i,idx) = ip(1);
            POST.syy_ip(i,idx) = ip(2);
            POST.sxy_ip(i,idx) = ip(3);
                   
            if nint_p==2
                P_ip(:,idx) = [1; xi; eta; eta*xi];       
            else
                P_ip(:,idx) = [1; xi; eta; eta*xi; xi^2; eta^2; xi^2*eta; xi*eta^2; (xi*eta)^2];
            end
        end
    end    
    
    a_xx = POST.sxx_ip(i,:)/P_ip;
    a_yy = POST.syy_ip(i,:)/P_ip;
    a_xy = POST.sxy_ip(i,:)/P_ip;
    
    idx = 0;

    if (nint_p==2)
        k = [-1, -1, 1, 1]; % xi
        m = [-1, 1, 1, -1]; % eta
        for idx = 1:4
            P = [1; k(idx); m(idx); k(idx)*m(idx)];
            POST.sxx(i,idx) = a_xx*P;
            POST.syy(i,idx) = a_yy*P;
            POST.sxy(i,idx) = a_xy*P;
        end
    elseif (nint_p==3)
        k = [-1, -1, 1, 1, -1, 0, 1, 0, 0]; % xi
        m = [-1, 1, 1, -1, 0, 1, 0, -1, 0]; % eta
        for idx = 1:9
            P = [1; k(idx); m(idx); k(idx)*m(idx); k(idx)^2; m(idx)^2; k(idx)^2*m(idx); k(idx)*m(idx)^2; (k(idx)*m(idx))^2];
            POST.sxx(i,idx) = a_xx*P;
            POST.syy(i,idx) = a_yy*P;
            POST.sxy(i,idx) = a_xy*P;
        end
    end
     
end


end
