clear all
close all
clc

addpath 'input'
addpath 'plot'

% Struct defined in order to show the results
RESULT = struct();

% --- 1. Pre-process
INPUT = input_open_hole_bilinear_570_els;

% --- 2. Solution
[MODEL,PROPERTY,POST,RESULT] = fem_solver(INPUT,RESULT);

% --- 3. Post-process - plot results
% Plot of the structure and its deformed positions:
plot_def_vs_undef(MODEL,POST); 

% --- 4. Strain energy
Uen = 1/2*MODEL.U.'*MODEL.K*MODEL.U % strain energy
Ven = -MODEL.U.'*MODEL.F; % potential
TOTen = Uen+Ven % total strain energy

% --- 5. Results
% --- 44 elements, bilinear:
% RESULT.J1_44_bilinear
% RESULT.J27_44_bilinear
% RESULT.J33_44_bilinear

% --- 570 elements, bilinear:
% POST.sxx(346,:);
% POST.syy(346,:);
% POST.sxy(346,:);

% --- Results for all cases
% Maximum displacements:
u_x_max = max(abs(MODEL.U_unc(1:MODEL.dofs/2)))
u_y_max = max(abs(MODEL.U_unc(MODEL.dofs/2+1:MODEL.dofs)))

% --- Maximum stresses:
sxx_max = max(max(abs(POST.sxx_ip)))
syy_max = max(max(abs(POST.syy_ip)))
sxy_max = max(max(abs(POST.sxy_ip)))


% --- Plot of the stresses
figure
hold on
grid on
sgtitle('Stresses')
plot_stresses(MODEL,POST,POST.sxx_ip,['\sigma_{xx, max} = ',num2str(sxx_max),' MPa'],1);
plot_stresses(MODEL,POST,POST.syy_ip,['\sigma_{yy, max} = ',num2str(syy_max),' MPa'],2);
plot_stresses(MODEL,POST,POST.sxy_ip,['\sigma_{xy, max} = ',num2str(sxy_max),' MPa'],3);

% --- Plot of the displacements
plot_displacements(MODEL)




