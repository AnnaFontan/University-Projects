function plot_def_vs_undef(MODEL,POST)

figure
hold on
grid on

nNODES = size(MODEL.nodes,1);
nEL = MODEL.nels;
in = MODEL.U_unc; % displacements without considering the constraints 
in(MODEL.constr_dofs) = 0;
n = 4; % number of nodes to consider for the plot

for i=1:nEL % loop over the elements
    el = MODEL.elements(i,1:n); % define the nodes of the element

    % Nodes of the original structure
    scatter(MODEL.nodes(el,1),MODEL.nodes(el,2),15,'black','filled')
    % Nodes of the deformed structure
    x_def = MODEL.nodes(el,1) + in(el,1); % x coordinate deformed
    y_def = MODEL.nodes(el,2) + in(el + nNODES,1); % y coordinate deformed
    scatter(x_def,y_def,15,'m','filled')
    
    % Original structure
    in_s = plot(MODEL.nodes(el,1),MODEL.nodes(el,2),'black');
    Dx = [MODEL.nodes(el(4),1),MODEL.nodes(el(1),1)];
    Dy = [MODEL.nodes(el(4),2),MODEL.nodes(el(1),2)];
    plot(Dx,Dy,'black')
    
    % Deformed structure   
    def_s = plot(x_def,y_def,'m');
    Dx_def = [x_def(4),x_def(1)];
    Dy_def = [y_def(4),y_def(1)];
    plot(Dx_def,Dy_def,'m')

end

title('Deformed shape')
legend([in_s def_s],{'Initial structure','Deformed structure'})
xlabel('x [mm]')
ylabel('y [mm]')



end