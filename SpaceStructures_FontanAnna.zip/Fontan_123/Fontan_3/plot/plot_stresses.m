function plot_stresses(MODEL,POST,S,tit,pos)
% Patch of the stresses

subplot(2,2,pos)

nEL = MODEL.nels;
nNODES = size(MODEL.nodes,1);
xGauss = MODEL.int_rule.x;
nint_p = length(xGauss);

% Displacements
in = MODEL.U_unc;
in(MODEL.constr_dofs) = 0;
n = 4; % number of nodes to consider for the patch

for i = 1:nEL % loop over the element
    el_nodes = MODEL.elements(i,1:n); % nodes for each element
    x = MODEL.nodes(el_nodes,1) + in(el_nodes,1); % x coordinate deformed
    y = MODEL.nodes(el_nodes,2) + in(el_nodes + nNODES,1); % y coordinate deformed

    % To match the order used in the previous functions
    sigma = [S(i,1) S(i,3) S(i,4) S(i,2)]; 
    
    h = patch(x,y,sigma);
    set(h,'LineStyle','none');   
end

colormap(jet)
c = colorbar;
title(tit)
axis off


end