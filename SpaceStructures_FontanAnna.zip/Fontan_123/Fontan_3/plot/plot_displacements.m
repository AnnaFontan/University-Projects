function plot_displacements(MODEL)
% Patch of the displacements

figure
sgtitle('Displacements')

nEL = MODEL.nels; % number of elements
nNODES = size(MODEL.nodes,1); % number of nodes

% Displacements
in = MODEL.U_unc;
in(MODEL.constr_dofs) = 0;
n = 4; % number of nodes to consider for the plots

% Maximum displacements:
u_x_max = max(abs(MODEL.U_unc(1:MODEL.dofs/2)));
u_y_max = max(abs(MODEL.U_unc(MODEL.dofs/2+1:MODEL.dofs)));

%% Ux
subplot(2,2,1)
hold on
grid on
x = [];
y = [];

for i=1:nEL
    el_nodes = MODEL.elements(i,1:n);
    Ux(i,:) = in(el_nodes); 
    x(i,:) = MODEL.nodes(el_nodes,1)';
    y(i,:) = MODEL.nodes(el_nodes,2)';
    
    h = patch(x(i,:),y(i,:),Ux(i,:));
    set(h,'LineStyle','none');    
end
colormap(jet)
c = colorbar;
title('u_{xx} [mm]')
axis off

%% Uy
subplot(2,2,2)
hold on
grid on

for i=1:nEL
    el_nodes = MODEL.elements(i,1:n);
    Uy(i,:) = in(el_nodes + nNODES); 
    
    h = patch(x(i,:),y(i,:),Uy(i,:));
    set(h,'LineStyle','none');    
end
colormap(jet)
c = colorbar;
title('u_{yy} [mm]')
axis off

%% U tot
subplot(2,2,3)
hold on
grid on

for i=1:nEL
    el_nodes = MODEL.elements(i,1:n);
    Utot(i,:) = sqrt((Ux(i,:)).^2 + (Uy(i,:)).^2); 

    h = patch(x(i,:),y(i,:),Utot(i,:));
    set(h,'LineStyle','none');    
end
colormap(jet)
c = colorbar;
title('u_{tot} [mm]')
axis off

end