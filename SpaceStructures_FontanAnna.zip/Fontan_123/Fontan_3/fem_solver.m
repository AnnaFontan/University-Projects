function [MODEL,PROPERTY,POST,RESULT] = fem_solver(INPUT,RESULT)

% --- Set model
[MODEL,PROPERTY,POST] = set_model(INPUT);

% --- Set pointers
MODEL = set_pointers(MODEL);

% --- Build & assembly matrices
[MODEL,RESULT] = build_K_matrix(MODEL,PROPERTY,RESULT);

% --- Impose constraints and solve
MODEL = solve_structure(MODEL); % To remove rows and columns

% --- Stress recovery
POST = stress_recovery(MODEL,PROPERTY,POST);

end