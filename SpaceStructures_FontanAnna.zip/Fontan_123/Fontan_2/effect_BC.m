function [om1,bcs] = effect_BC(INPUT)
% Function that permits to analyse the effect of the boundary conditions over the first natural frequency

if strcmp(INPUT.bcs,'CCCC')
    INPUT.bcs = 'SSSS';
else
    INPUT.bcs = 'CCCC';
end
bcs = INPUT.bcs;

[PLATE,RITZ,LOAD] = set_model(INPUT);
TRIAL = set_trial_fcs(PLATE.bcs);

% --- Evaluate integrals
IRITZ = evaluate_integrals(TRIAL,PLATE,RITZ,LOAD);

% --- Assembly stiffness matrices
K = assembly_stiffness(PLATE,IRITZ);
F = assembly_load_vector(LOAD,IRITZ);

% --- Solve the linear static problem
RITZ.C = K\F;

% --- Post-process
[om1] = free_vibrations(PLATE,RITZ,TRIAL,K,F,IRITZ);

end