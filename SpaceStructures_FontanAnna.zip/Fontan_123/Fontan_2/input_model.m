function [INPUT] = input_model

INPUT.a = 400; % [mm]       {100, 200, 400}
INPUT.b = 200; % [mm]
INPUT.E = 72000; % [MPa]
INPUT.nu = 0.3000; % [-]
INPUT.t = 1; % [mm]
INPUT.I0 = 2.7000e-09; % [N/mm^2]
INPUT.bcs = 'CCCC'; % or 'SSSS'
INPUT.D = INPUT.E*INPUT.t^3/(12*(1-INPUT.nu^2))*[1 INPUT.nu 0; INPUT.nu 1 0; 0 0 (1-INPUT.nu)/2];

INPUT.load_type = 'uniform'; % or 'concentrated'
INPUT.p0 = 10^-3; % distributed load [N/mm^2]
INPUT.P = [10 INPUT.a/2 INPUT.b/2]; % concentrated load applied in the middle [N]

end