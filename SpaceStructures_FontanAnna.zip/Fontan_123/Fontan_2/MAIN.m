clear variables
close all
clc

addpath 'plot'
addpath 'convergence'

% --- 1. Input data
INPUT = input_model;

[PLATE,RITZ,LOAD] = set_model(INPUT);
TRIAL = set_trial_fcs(PLATE.bcs);

% --- 2. Evaluate integrals
IRITZ = evaluate_integrals(TRIAL,PLATE,RITZ,LOAD);

% --- 3. Assembly stiffness matrices
K = assembly_stiffness(PLATE,IRITZ);
F = assembly_load_vector(LOAD,IRITZ);

% --- 4. Solve the linear static problem
RITZ.C = K\F;

% --- 5. Post-process
w_mid = bending_response(PLATE,RITZ,TRIAL);
om1 = free_vibrations(PLATE,RITZ,TRIAL,K,F,IRITZ);
bcs1 = INPUT.bcs;

% --- 6. Other requests
% convergence_w_mid(PLATE,TRIAL,LOAD,w_mid); % output: plot
% convergence_om(PLATE,TRIAL,LOAD,IRITZ); % output: plot
[om2,bcs2] = effect_BC(INPUT);

% --- 7. Results
fprintf('Case of %s:',bcs1);
om1
fprintf('Case of %s:',bcs2);
om2
w_mid







