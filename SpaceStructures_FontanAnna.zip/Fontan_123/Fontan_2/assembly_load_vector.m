function F = assembly_load_vector(LOAD,IRITZ)

Jx = IRITZ.Jx; % (R x 1)
Jy = IRITZ.Jy; % (S x 1)
    
F = LOAD.p0*kron(Jx,Jy); % ((RXS) x 1)

end