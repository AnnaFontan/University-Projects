function [w_mid] = bending_response(PLATE,RITZ,TRIAL)

a = PLATE.a;
b = PLATE.b;
x = linspace(0,a,RITZ.R*RITZ.S);
y = linspace(0,b,RITZ.R*RITZ.S);
D = PLATE.D;

figure
hold on

nexttile

for j=1:RITZ.S
    C(:,j) = RITZ.C(RITZ.R*(j-1)+1:(RITZ.R*j),1);
end

phi_x = TRIAL.phi(x.',a,1:RITZ.R);
psi_y = TRIAL.psi(y.',b,1:RITZ.S).';
phi_1devx = TRIAL.dphi(x.',a,1:RITZ.R);
psi_1devy = TRIAL.dpsi(y.',b,1:RITZ.S).';
phi_2devx = TRIAL.ddphi(x.',a,1:RITZ.R);
psi_2devy = TRIAL.ddpsi(y.',b,1:RITZ.S).';
 
w_mid = TRIAL.phi(a/2,a,1:RITZ.R)*C*TRIAL.psi(b/2,b,1:RITZ.S).';

%% w
w = phi_x*C*psi_y;
[X,Y] = meshgrid(x,y);
[L,h] = contourf(X,Y,w,30);
title('w')
set(h,'LineColor','none')
colorbar
camroll(90)
 
%% Mxx
w_dev_xx = - phi_2devx*C*psi_y;
w_dev_yy = - phi_x*C*psi_2devy;
Mxx = D(1,1)*w_dev_xx + D(1,2)*w_dev_yy;
nexttile
[L,h] = contourf(X,Y,Mxx,30);
title('Mxx')
set(h,'LineColor','none')
colorbar
camroll(90)

%% Myy
w_dev_xx = - psi_y'*C*phi_2devx';
w_dev_yy = - psi_2devy'*C*phi_x';
Myy = D(1,2)*w_dev_xx + D(2,2)*w_dev_yy;
nexttile
[L,h] = contourf(X,Y,Myy,30);
title('Myy')
set(h,'LineColor','none')
colorbar
camroll(90)

%% Mxy
w_dev_xy = - 2*phi_1devx*C*psi_1devy;
Mxy = D(3,3)*w_dev_xy;
nexttile
[L,h] = contourf(X,Y,Mxy,30);
title('Mxy')
set(h,'LineColor','none')
colorbar
camroll(90)

end