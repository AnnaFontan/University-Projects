function om1 = free_vibrations(PLATE,RITZ,TRIAL,K,F,IRITZ)

figure
hold on
sgtitle('Free vibrations')

a = PLATE.a;
b = PLATE.b;
t = PLATE.t;
I0 = PLATE.I0;

x = linspace(0,a,RITZ.R*RITZ.S);
y = linspace(0,b,RITZ.R*RITZ.S);
phi_x = TRIAL.phi(x.',a,1:RITZ.R);
psi_y = TRIAL.psi(y.',b,1:RITZ.S).';

for j=1:RITZ.S
    C(:,j) = RITZ.C(RITZ.R*(j-1)+1:(RITZ.R*j),1);
end
w = phi_x*C*psi_y;

D = PLATE.E*PLATE.t^3/(12*(1-PLATE.nu^2)); % [Mpa*mm^3]
M = I0*kron(IRITZ.Ixx_00,IRITZ.Iyy_00);

[v,Ome2] = eig(K,M);
om = sqrt(diag(Ome2));
om_bar = om*a^2*(sqrt(I0/(D)));
om1 = om_bar(1:4).'; % output of the function: related to the modes 1,2,3 e 4

[X,Y] = meshgrid(x,y);

for mode = 1:4
    subplot(2,2,mode)
    
    vib = v(:,mode);
    for j=1:RITZ.S
        C_vib(:,j) = vib(RITZ.R*(j-1)+1:(RITZ.R*j),1);
    end
    w_vib = phi_x*C_vib*psi_y;
    w_def = w + w_vib;

    [L,h] = contourf(X,Y,w_def,30);
    title(['Mode ',num2str(mode)])
    set(h,'LineColor','none')
    camroll(90)
end

end