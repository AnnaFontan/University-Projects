function [] = convergence_w_mid(PLATE,TRIAL,LOAD,k)
% Study the convergence of the mid-displacement in the case of uniform and
% concentrated loads

a = PLATE.a;
b = PLATE.b;

D = PLATE.E*PLATE.t^3/(12*(1-PLATE.nu^2)); % [Mpa*mm^3]

figure
hold on
grid on

for n = 1:10 % number of trial functions
    C = [];
    C_1 = [];
    x = [];
    y = [];
    K = [];
    F = [];
    
    RITZ.R = n;
    RITZ.S = n;

    x = linspace(0,a,n*n);
    y = linspace(0,b,n*n);

    [IRITZ] = evaluate_integrals(TRIAL,PLATE,RITZ,LOAD);
    K = assembly_stiffness(PLATE,IRITZ);
    F = assembly_load_vector(LOAD,IRITZ);
    C_1 = K\F;

    for j = 1:n
        C(:,j) = C_1(n*(j-1)+1:(n*j),1);
    end

    w_mid = TRIAL.phi(a/2,a,1:n)*C*TRIAL.psi(b/2,b,1:n).';
    scatter(n,w_mid,'filled','black');
   
end

xlabel('Number of trial functions')
ylabel('w_{mid}')
v = plot([0,n],k*[1,1],'m');
title('Convergence of the mid-displacement');
legend([v],{'w_{mid} for R, S = 5'})

end