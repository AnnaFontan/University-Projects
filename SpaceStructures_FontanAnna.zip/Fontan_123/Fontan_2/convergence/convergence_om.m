function [] = convergence_om(PLATE,TRIAL,LOAD,IRITZ)
% Study the convergence of the first natural frequency for different values of R
% and S

a = PLATE.a;
b = PLATE.b;
D = PLATE.E*PLATE.t^3/(12*(1-PLATE.nu^2)); % [Mpa*mm^3]

figure
hold on
grid on

for n = 1:9 % number of trial functions
    K = [];
    v = [];
    Ome2 = [];
    x = [];
    y = [];
    M = [];
    
    RITZ.R = n;
    RITZ.S = n;

    x = linspace(0,a,n*n);
    y = linspace(0,b,n*n);

    [IRITZ] = evaluate_integrals(TRIAL,PLATE,RITZ,LOAD);
    M = PLATE.I0*kron(IRITZ.Ixx_00,IRITZ.Iyy_00);
    K = assembly_stiffness(PLATE,IRITZ);    

    [v,Ome2] = eig(K,M);
    om = sqrt(diag(Ome2));
    om_n = om(1)*a^2*(sqrt(PLATE.I0/(D)));

    p = scatter(n,om_n,'filled','black');
   
end

xlabel('Number of trial functions')
ylabel('First natural frequency')
title('Convergence of the first natural frequency');

end