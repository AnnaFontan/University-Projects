function TRIAL = set_trial_fcs(bcs)

%% TRIAL
% TRIAL = struct with fields:
%   phi         Ritz functions along x
%   dphi        x-derivative of phi
%   ddphi       x-derivative of dphi
%   psi         Ritz functions along y
%   dpsi        x-derivative of psi
%   ddpsi       x-derivative of dpsi


if strcmp(bcs,'CCCC') % Clamped-Clamped
    TRIAL.phi = @(x,a,i) (x./a).^(i+3) - 2.*(x./a).^(i+2) + (x./a).^(i+1);
    TRIAL.dphi = @(x,a,i) (i+3)/a.*(x/a).^(i+2) - 2/a.*(i+2).*(x./a).^(i+1) + (i+1)/a.*(x./a).^i;
    TRIAL.ddphi = @(x,a,i) (i+3).*(i+2)./a^2.*(x./a).^(i+1) - 2.*(i+2).*(i+1)./a^2.*(x./a).^i + i.*(i+1)/a^2.*(x./a).^(i-1);
    TRIAL.psi = @(x,a,i) (x./a).^(i+3) - 2.*(x./a).^(i+2) + (x./a).^(i+1);
    TRIAL.dpsi = @(x,a,i) (i+3)/a.*(x/a).^(i+2) - 2/a.*(i+2).*(x./a).^(i+1) + (i+1)/a.*(x./a).^i;
    TRIAL.ddpsi = @(x,a,i) (i+3).*(i+2)./a^2.*(x./a).^(i+1) - 2.*(i+2).*(i+1)./a^2.*(x./a).^i + i.*(i+1)/a^2.*(x./a).^(i-1);
elseif strcmp(bcs,'SSSS') % Simply-Supported
    TRIAL.phi = @(x,a,i) sin(i.*pi.*x./a);
    TRIAL.dphi = @(x,a,i) (i.*pi./a).*cos(i.*pi.*x./a);
    TRIAL.ddphi = @(x,a,i) -(i.*pi./a).^2.*sin(i.*pi.*x./a);
    TRIAL.psi = @(x,a,i) sin(i.*pi.*x./a);
    TRIAL.dpsi = @(x,a,i) (i.*pi./a).*cos(i.*pi.*x./a);
    TRIAL.ddpsi = @(x,a,i) -(i.*pi./a).^2.*sin(i.*pi.*x./a);
end

end