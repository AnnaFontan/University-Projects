function [PLATE,RITZ,LOAD] = set_model(INPUT)

%% PLATE
% PLATE = struct with fields:
%     a     [mm]        PLATE dimension along x
%     b     [mm]        PLATE dimension along y
%     E     [Mpa]       Young�s modulus
%     nu    [-]         Poisson�s ratio
%     t     [mm]        thickness
%     I0    [N/mm^2]    INPUT inertia
%     bcs               boundary conditions
%     D                 bending stiffness [3�3 double]

PLATE.a = INPUT.a;
PLATE.b = INPUT.b;
PLATE.E = INPUT.E;
PLATE.nu = INPUT.nu;
PLATE.t = INPUT.t;
PLATE.I0 = INPUT.I0;
PLATE.bcs = INPUT.bcs;
PLATE.D = INPUT.D;

%% RITZ
% RITZ = struct with fields:
%     R                 number of trial functions along x
%     S                 number of trial functions along y
%     C                 Ritz amplitudes[9�1 double]

RITZ.R = 5;
RITZ.S = 5;
RITZ.C = zeros(RITZ.R*RITZ.S,1);


%% LOAD
% LOAD = struct with fields:
%   p0                  pressure load intensity
%   load_type           'uniform' or 'concentrated'
%   load_pos_x0         x-position of concentrated load (if any)
%   load_pos_y0         y-position of concentrated load (if any)

LOAD.load_type = INPUT.load_type;
if strcmp(LOAD.load_type,'uniform')
    LOAD.p0 = INPUT.p0;
    LOAD.load_pos_x0 = [];
    LOAD.load_pos_y0 = [];
else % concentrated load
    LOAD.p0 = INPUT.P(1);
    LOAD.load_pos_x0 = INPUT.P(2);
    LOAD.load_pos_y0 = INPUT.P(3);
end

end