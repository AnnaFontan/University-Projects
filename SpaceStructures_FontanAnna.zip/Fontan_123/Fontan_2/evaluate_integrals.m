function [IRITZ] = evaluate_integrals(TRIAL,PLATE,RITZ,LOAD)

a = PLATE.a;
b = PLATE.b;
R = RITZ.R;
S = RITZ.S;
phi = TRIAL.phi;
dphi = TRIAL.dphi;
ddphi = TRIAL.ddphi;

for i=1:R
    for j=1:S
        IRITZ.Ixx_00(i,j) = integral(@(x) phi(x,a,i).*phi(x,a,j),0,a);
        IRITZ.Ixx_02(i,j) = integral(@(x) phi(x,a,i).*ddphi(x,a,j),0,a);
        IRITZ.Ixx_11(i,j) = integral(@(x) dphi(x,a,i).*dphi(x,a,j),0,a);
        IRITZ.Ixx_20(i,j) = integral(@(x) ddphi(x,a,i).*phi(x,a,j),0,a);
        IRITZ.Ixx_22(i,j) = integral(@(x) ddphi(x,a,i).*ddphi(x,a,j),0,a);

        IRITZ.Iyy_00(i,j) = integral(@(y) phi(y,b,i).*phi(y,b,j),0,b);
        IRITZ.Iyy_02(i,j) = integral(@(y) phi(y,b,i).*ddphi(y,b,j),0,b);
        IRITZ.Iyy_11(i,j) = integral(@(y) dphi(y,b,i).*dphi(y,b,j),0,b);
        IRITZ.Iyy_20(i,j) = integral(@(y) ddphi(y,b,i).*phi(y,b,j),0,b);
        IRITZ.Iyy_22(i,j) = integral(@(y) ddphi(y,b,i).*ddphi(y,b,j),0,b);
    end
    
    if strcmp(LOAD.load_type,'uniform')
        IRITZ.Jx(i,1) = integral(@(x) phi(x,a,i),0,a);
        IRITZ.Jy(i,1) = integral(@(y) phi(y,b,i),0,b);
    elseif strcmp(LOAD.load_type,'concentrated')
        IRITZ.Jx(i,1) = phi(LOAD.load_pos_x0,a,i);
        IRITZ.Jy(i,1) = phi(LOAD.load_pos_y0,b,i);
    end

end
end