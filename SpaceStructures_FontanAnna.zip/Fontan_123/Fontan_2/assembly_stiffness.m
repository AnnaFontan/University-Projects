function K = assembly_stiffness(PLATE,IRITZ)

D11 = PLATE.D(1,1);
D12 = PLATE.D(1,2);
D22 = PLATE.D(2,2);
D66 = PLATE.D(3,3);
Ixx_22 = IRITZ.Ixx_22;
Ixx_20 = IRITZ.Ixx_20;
Ixx_02 = IRITZ.Ixx_02;
Ixx_00 = IRITZ.Ixx_00;
Ixx_11 = IRITZ.Ixx_11;
Iyy_22 = IRITZ.Iyy_22;
Iyy_20 = IRITZ.Iyy_20;
Iyy_02 = IRITZ.Iyy_02;
Iyy_00 = IRITZ.Iyy_00;
Iyy_11 = IRITZ.Iyy_11;

% --- Build stiffness matrix

K = D11*kron(Ixx_22,Iyy_00) + ...
    D12*(kron(Ixx_20,Iyy_02) + kron(Ixx_02,Iyy_20)) + ...
    D22*kron(Ixx_00,Iyy_22) + ...
    4*D66*kron(Ixx_11,Iyy_11);

end